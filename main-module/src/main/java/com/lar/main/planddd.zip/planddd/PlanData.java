package com.lar.main.planddd;

import lombok.Data;

// 组装领域数据的的值对象，目的是为了聚合改业务中所使用的所有对象。对象体现业务
@Data
public class PlanData {

}
