package com.lar.main.planddd.model;

// 对前端数据进行校验
public class PlanQuery {
}
