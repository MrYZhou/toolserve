package com.lar.main.planddd.model;

// 对前端数据进行返回的封装
public class PlanInfo {
}
