package com.lar.main.planddd;

import org.springframework.stereotype.Service;

import java.util.List;

//可以认为的服务编排的类，用于展示业务服务调用流
@Service
public class PlanServiceAction {

    public List findAll() {
        // 第一步获取组装仓库的数据

        // 主业务 (操作属性变化的业务）

        // 其他支线

        return null;
    }
}
