package com.lar.main.planddd.domain.repository;

import java.util.List;

//定义查询的接口
public interface PlanRepositoty {
    List findAll();
}
